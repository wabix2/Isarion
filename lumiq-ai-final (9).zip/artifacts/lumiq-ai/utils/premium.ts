import { Platform } from "react-native";
import type {
  CustomerInfo,
  PurchasesPackage,
  PurchasesOffering,
} from "react-native-purchases";

// Keys come from environment variables — never hardcode in source
const REVENUECAT_ANDROID_API_KEY =
  process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY ?? "";

export const ENTITLEMENT_ID = "lumiq_ai_pro";

let initialized = false;
let initializationPromise: Promise<void> | null = null;
let pendingUserId: string | null = null;
let activeUserId: string | null = null;

// Keep the native module out of the app's eager route-loading path. This is
// important for Expo Go and for builds where the native module is unavailable.
let purchasesModulePromise: Promise<typeof import("react-native-purchases") | null> | null = null;

async function getPurchasesModule(): Promise<typeof import("react-native-purchases") | null> {
  if (Platform.OS !== "android") return null;
  if (!purchasesModulePromise) {
    purchasesModulePromise = import("react-native-purchases").catch((error) => {
      console.warn("[RevenueCat] Native module failed to load:", error);
      return null;
    });
  }
  return purchasesModulePromise;
}

export async function initializePurchases(userId?: string): Promise<void> {
  if (Platform.OS !== "android") return;
  const requestedUserId = userId ?? pendingUserId ?? undefined;
  if (initialized) {
    if (requestedUserId && requestedUserId !== activeUserId) {
      await switchPurchasesUser(requestedUserId);
    }
    return;
  }
  if (initializationPromise) return initializationPromise;

  const apiKey = REVENUECAT_ANDROID_API_KEY;
  if (!apiKey) {
    console.warn("[RevenueCat] API key not configured — purchases unavailable");
    return;
  }

  initializationPromise = (async () => {
    try {
      const purchasesModule = await getPurchasesModule();
      const Purchases = purchasesModule?.default;
      if (!Purchases) return;

      Purchases.setLogLevel(
        __DEV__
          ? purchasesModule.LOG_LEVEL.DEBUG
          : purchasesModule.LOG_LEVEL.ERROR,
      );
      Purchases.configure({ apiKey, appUserID: requestedUserId });
      initialized = true;
      activeUserId = requestedUserId ?? null;
    } catch (error) {
      console.warn("[RevenueCat] Failed to initialize:", error);
    } finally {
      initializationPromise = null;
    }
  })();

  return initializationPromise;
}

export function isPurchasesInitialized(): boolean {
  return initialized;
}

/**
 * Record the Clerk identity without loading RevenueCat. The next lazy
 * initialization uses this ID, and an already initialized client is switched
 * to the new user without touching the app startup path.
 */
export function setRevenueCatUserId(userId: string | null): void {
  pendingUserId = userId;
  if (!initialized) return;

  if (userId && userId !== activeUserId) {
    void switchPurchasesUser(userId);
  } else if (!userId && activeUserId) {
    void clearPurchasesUser();
  }
}

async function switchPurchasesUser(userId: string): Promise<void> {
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return;
    await Purchases.logIn(userId);
    activeUserId = userId;
  } catch (error) {
    console.warn("[RevenueCat] logIn failed:", error);
  }
}

async function clearPurchasesUser(): Promise<void> {
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return;
    await Purchases.logOut();
    activeUserId = null;
  } catch (error) {
    console.warn("[RevenueCat] logOut failed:", error);
  }
}

export async function isPremiumUser(): Promise<boolean> {
  if (Platform.OS !== "android") return false;
  if (!initialized) await initializePurchases();
  if (!initialized) return false;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return false;
    const info = await Purchases.getCustomerInfo();
    return isEntitlementActive(info);
  } catch {
    return false;
  }
}

function isEntitlementActive(info: CustomerInfo): boolean {
  return typeof info.entitlements.active[ENTITLEMENT_ID] !== "undefined";
}

export interface LumiqOffering {
  monthly:  PurchasesPackage | null;
  yearly:   PurchasesPackage | null;
  lifetime: PurchasesPackage | null;
  raw:      PurchasesOffering | null;
}

export async function getOffering(): Promise<LumiqOffering> {
  const empty: LumiqOffering = { monthly: null, yearly: null, lifetime: null, raw: null };
  if (Platform.OS !== "android" || !initialized) return empty;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return empty;
    const offerings = await Purchases.getOfferings();
    const current = offerings.current;
    if (!current) return empty;

    let monthly:  PurchasesPackage | null = null;
    let yearly:   PurchasesPackage | null = null;
    let lifetime: PurchasesPackage | null = null;

    for (const pkg of current.availablePackages) {
      if (pkg.packageType === purchasesModule.PACKAGE_TYPE.MONTHLY)  monthly  = pkg;
      if (pkg.packageType === purchasesModule.PACKAGE_TYPE.ANNUAL)   yearly   = pkg;
      if (pkg.packageType === purchasesModule.PACKAGE_TYPE.LIFETIME) lifetime = pkg;
    }

    // Fallback: match by product identifier if package types are not set
    if (!monthly || !yearly || !lifetime) {
      for (const pkg of current.availablePackages) {
        const id = pkg.product.identifier.toLowerCase();
        if (!monthly  && id.includes("monthly"))  monthly  = pkg;
        if (!yearly   && (id.includes("yearly") || id.includes("annual"))) yearly = pkg;
        if (!lifetime && id.includes("lifetime")) lifetime = pkg;
      }
    }

    return { monthly, yearly, lifetime, raw: current };
  } catch (e) {
    console.warn("[RevenueCat] getOffering failed:", e);
    return empty;
  }
}

export async function purchasePackage(pkg: PurchasesPackage): Promise<boolean> {
  if (Platform.OS !== "android" || !initialized) return false;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return false;
    const { customerInfo } = await Purchases.purchasePackage(pkg);
    return isEntitlementActive(customerInfo);
  } catch (e: any) {
    if (e?.userCancelled) return false;
    throw e;
  }
}

export async function restorePurchases(): Promise<boolean> {
  if (Platform.OS !== "android" || !initialized) return false;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return false;
    const info = await Purchases.restorePurchases();
    return isEntitlementActive(info);
  } catch {
    return false;
  }
}

export async function getCustomerInfo(): Promise<CustomerInfo | null> {
  if (Platform.OS !== "android" || !initialized) return null;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return null;
    return await Purchases.getCustomerInfo();
  } catch {
    return null;
  }
}

export async function logInUser(userId: string): Promise<void> {
  if (Platform.OS !== "android" || !initialized) return;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return;
    await Purchases.logIn(userId);
  } catch (e) {
    console.warn("[RevenueCat] logIn failed:", e);
  }
}

export async function logOutUser(): Promise<void> {
  if (Platform.OS !== "android" || !initialized) return;
  try {
    const purchasesModule = await getPurchasesModule();
    const Purchases = purchasesModule?.default;
    if (!Purchases) return;
    await Purchases.logOut();
  } catch (e) {
    console.warn("[RevenueCat] logOut failed:", e);
  }
}

// Legacy alias — keeps older call sites working
export async function purchasePremium(): Promise<boolean> {
  const offering = await getOffering();
  const pkg = offering.monthly ?? offering.yearly ?? offering.lifetime;
  if (!pkg) return false;
  return purchasePackage(pkg);
}
