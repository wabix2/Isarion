import test from "node:test";
import assert from "node:assert/strict";
import { HealthCheckResponse } from "@workspace/api-zod";

test("health check payload matches the published schema", () => {
  const parsed = HealthCheckResponse.parse({ status: "ok" });
  assert.equal(parsed.status, "ok");
});
