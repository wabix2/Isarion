import { Router, type IRouter } from "express";
import healthRouter from "./health";
import chatRouter from "./chat";
import progressRouter from "./progress";
import leaderboardRouter from "./leaderboard";
import learnerModelRouter from "./learner-model";

const router: IRouter = Router();

router.use(healthRouter);
router.use(chatRouter);
router.use(progressRouter);
router.use(leaderboardRouter);
router.use(learnerModelRouter);

export default router;
