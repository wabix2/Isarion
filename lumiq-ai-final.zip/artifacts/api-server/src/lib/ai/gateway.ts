import { GoogleGenerativeAI } from "@google/generative-ai";
import { logger } from "../logger";

export type AIMessage = {
  role: "user" | "assistant";
  text: string;
};

export class AIGatewayError extends Error {
  constructor(
    message: string,
    public readonly feature: string,
    public readonly retryable = false,
  ) {
    super(message);
    this.name = "AIGatewayError";
  }
}

type CompletionOptions = {
  feature: string;
  systemInstruction: string;
  prompt: string;
  history?: AIMessage[];
  maxOutputTokens?: number;
};

const DEFAULT_MODEL = process.env.GEMINI_MODEL ?? "gemini-2.0-flash";
const MAX_ATTEMPTS = 3;
const REQUEST_TIMEOUT_MS = 20_000;

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * The only module allowed to construct a Gemini client.
 *
 * Every call has the same timeout, retry, error, and usage logging behavior.
 * The gateway deliberately does not route between models or cache results;
 * those concerns belong to later layers.
 */
export class AIGateway {
  private readonly client: GoogleGenerativeAI;

  constructor(apiKey = process.env.GEMINI_API_KEY) {
    if (!apiKey) {
      throw new AIGatewayError("Gemini API key not configured.", "gateway");
    }
    this.client = new GoogleGenerativeAI(apiKey);
  }

  private async complete(options: CompletionOptions): Promise<string> {
    let lastError: unknown;
    const startedAt = Date.now();

    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
      const attemptStartedAt = Date.now();
      try {
        const model = this.client.getGenerativeModel({
          model: DEFAULT_MODEL,
          generationConfig: {
            maxOutputTokens: options.maxOutputTokens ?? 700,
          },
        });
        const history = (options.history ?? []).map((message) => ({
          role: message.role === "assistant" ? ("model" as const) : ("user" as const),
          parts: [{ text: message.text }],
        }));
        const chat = model.startChat({
          history,
          systemInstruction: options.systemInstruction,
        });

        const result = await Promise.race([
          chat.sendMessage(options.prompt),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new AIGatewayError("Gemini request timed out.", options.feature, true)), REQUEST_TIMEOUT_MS),
          ),
        ]);
        const text = result.response.text().trim();
        if (!text) {
          throw new AIGatewayError("Gemini returned an empty response.", options.feature, true);
        }

        logger.info(
          {
            feature: options.feature,
            attempt,
            latencyMs: Date.now() - attemptStartedAt,
            totalLatencyMs: Date.now() - startedAt,
          },
          "AI gateway call completed",
        );
        return text;
      } catch (error) {
        lastError = error;
        const retryable =
          error instanceof AIGatewayError
            ? error.retryable
            : /timeout|timed out|429|500|502|503|504|rate/i.test(String(error));
        if (!retryable || attempt === MAX_ATTEMPTS) break;
        await sleep(250 * 2 ** (attempt - 1));
      }
    }

    logger.error(
      {
        feature: options.feature,
        attempts: MAX_ATTEMPTS,
        latencyMs: Date.now() - startedAt,
        error: lastError instanceof Error ? lastError.message : String(lastError),
      },
      "AI gateway call failed",
    );
    if (lastError instanceof AIGatewayError) throw lastError;
    throw new AIGatewayError(
      lastError instanceof Error ? lastError.message : "Gemini request failed.",
      options.feature,
      false,
    );
  }

  askTutor(prompt: string, history: AIMessage[] = [], topic?: string): Promise<string> {
    return this.complete({
      feature: "askTutor",
      prompt,
      history,
      systemInstruction: `You are a focused study assistant. Answer clearly and concisely.
Give examples when they aid understanding. Keep responses under 200 words.
${topic ? `The learner is studying ${topic}.` : ""}`,
    });
  }

  evaluateFeynman(explanation: string, topic: string, history: AIMessage[] = []): Promise<string> {
    return this.complete({
      feature: "evaluateFeynman",
      prompt: explanation,
      history,
      maxOutputTokens: 300,
      systemInstruction: `You are a Feynman Technique mentor. The student is explaining ${topic}.
Identify the most important gap or incorrect claim, then ask exactly one sharp follow-up question.
Do not explain the concept yourself. Be encouraging and precise. Keep the response under 80 words.`,
    });
  }

  explainConcept(prompt: string, topic?: string): Promise<string> {
    return this.complete({
      feature: "explainConcept",
      prompt,
      systemInstruction: `Explain the concept accurately for a student.
Use one concrete example and avoid unnecessary jargon.${topic ? ` Focus on ${topic}.` : ""}`,
    });
  }

  analyzeMistake(prompt: string, topic?: string): Promise<string> {
    return this.complete({
      feature: "analyzeMistake",
      prompt,
      systemInstruction: `Analyze the learner's mistake. State the misconception, why it is wrong,
and one corrective practice step. Do not invent facts.${topic ? ` The concept is ${topic}.` : ""}`,
    });
  }

  generateQuiz(prompt: string, topic?: string): Promise<string> {
    return this.complete({
      feature: "generateQuiz",
      prompt,
      systemInstruction: `Generate a quiz as valid JSON with a questions array.
Each question must have q, options (four strings), and answer (zero-based integer).
Do not include markdown fences.${topic ? ` The topic is ${topic}.` : ""}`,
      maxOutputTokens: 1200,
    });
  }

  generateFlashcards(prompt: string, topic?: string): Promise<string> {
    return this.complete({
      feature: "generateFlashcards",
      prompt,
      systemInstruction: `Generate flashcards as valid JSON with a cards array.
Each card must have front and back strings. Do not include markdown fences.
${topic ? `The topic is ${topic}.` : ""}`,
      maxOutputTokens: 1000,
    });
  }

  generateStudyPlan(prompt: string): Promise<string> {
    return this.complete({
      feature: "generateStudyPlan",
      prompt,
      systemInstruction: "Generate a practical study plan as valid JSON with a title and steps array. Do not include markdown fences.",
      maxOutputTokens: 900,
    });
  }
}

export function createAIGateway(): AIGateway {
  return new AIGateway();
}