import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { knowledgeObjectTable } from "@workspace/db/schema";
import { isSafeReusableContent, stripPrivateContent } from "./knowledge-cache-safety";

const MAX_CACHE_AGE_DAYS = Number(process.env.KNOWLEDGE_CACHE_MAX_AGE_DAYS ?? 30);
const MIN_QUALITY_SCORE = Number(process.env.KNOWLEDGE_CACHE_MIN_QUALITY ?? 0.8);

export function normalizeQuestion(value: string): string {
  return value
    .toLowerCase()
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function keywords(value: string): Set<string> {
  return new Set(
    normalizeQuestion(value)
      .split(" ")
      .filter((word) => word.length > 2),
  );
}

export function cacheSimilarity(question: string, candidate: string): number {
  const left = normalizeQuestion(question);
  const right = normalizeQuestion(candidate);
  if (left === right) return 1;
  const a = keywords(left);
  const b = keywords(right);
  if (!a.size || !b.size) return 0;
  const intersection = [...a].filter((word) => b.has(word)).length;
  return intersection / Math.max(a.size, b.size);
}

type CachedAnswer = {
  explanation: string;
  examples: string[];
  misconceptions: string[];
  prerequisites: string[];
  difficulty: string;
};

export async function findReusableAnswer({
  question,
  subject,
  topic,
}: {
  question: string;
  subject?: string;
  topic?: string;
}): Promise<typeof knowledgeObjectTable.$inferSelect | null> {
  const normalized = normalizeQuestion(question);
  const filters = [sql`${knowledgeObjectTable.qualityScore} >= ${MIN_QUALITY_SCORE}`];
  if (subject) filters.push(eq(knowledgeObjectTable.subject, subject));
  if (topic) filters.push(eq(knowledgeObjectTable.topic, topic));

  const rows = await db
    .select()
    .from(knowledgeObjectTable)
    .where(and(...filters))
    .orderBy(desc(knowledgeObjectTable.qualityScore), desc(knowledgeObjectTable.usageCount))
    .limit(100);
  const maxAge = Date.now() - MAX_CACHE_AGE_DAYS * 86_400_000;
  const match = rows
    .filter((row) => row.updatedAt.getTime() >= maxAge)
    .map((row) => ({ row, score: cacheSimilarity(normalized, row.normalizedQuestion) }))
    .filter(({ score }) => score >= 0.85)
    .sort((a, b) => b.score - a.score)[0];
  if (!match) return null;

  await db
    .update(knowledgeObjectTable)
    .set({ usageCount: sql`${knowledgeObjectTable.usageCount} + 1`, updatedAt: new Date() })
    .where(eq(knowledgeObjectTable.id, match.row.id));
  return match.row;
}

export async function storeReusableAnswer({
  question,
  conceptId,
  subject,
  topic,
  answer,
}: {
  question: string;
  conceptId: string;
  subject?: string;
  topic?: string;
  answer: CachedAnswer;
}): Promise<void> {
  const explanation = stripPrivateContent(answer.explanation);
  const examples = answer.examples.map(stripPrivateContent).filter(isSafeReusableContent);
  const misconceptions = answer.misconceptions.map(stripPrivateContent).filter(isSafeReusableContent);
  const prerequisites = answer.prerequisites.map(stripPrivateContent).filter(isSafeReusableContent);
  if (!isSafeReusableContent(explanation)) return;

  await db.insert(knowledgeObjectTable).values({
    conceptId: stripPrivateContent(conceptId),
    subject: subject ? stripPrivateContent(subject) : undefined,
    topic: topic ? stripPrivateContent(topic) : undefined,
    normalizedQuestion: normalizeQuestion(question),
    explanation,
    examples,
    misconceptions,
    prerequisites,
    difficulty: answer.difficulty || "unknown",
    source: "gemini",
    confidence: 0.8,
    qualityScore: 0.8,
    usageCount: 0,
    updatedAt: new Date(),
  });
}