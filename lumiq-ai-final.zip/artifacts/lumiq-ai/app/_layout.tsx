import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { ClerkLoaded, ClerkProvider, useAuth } from "@clerk/expo";
// Use the installed Clerk Expo package's concrete token-cache entry. This
// avoids Metro's subpath-export resolution issue in the Expo 52 monorepo.
import { tokenCache } from "@clerk/expo/token-cache";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { Platform } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import LevelUpModal from "@/components/LevelUpModal";
import StreakFreezeUsedModal from "@/components/StreakFreezeUsedModal";
import StreakMilestoneModal from "@/components/StreakMilestoneModal";
import { UserProvider, useUser } from "@/context/UserContext";
import { initializePurchases, logInUser, logOutUser } from "@/utils/premium";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

const publishableKey = process.env.EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY!;
const proxyUrl = process.env.EXPO_PUBLIC_CLERK_PROXY_URL || undefined;

function GlobalCelebrations() {
  const {
    pendingLevelUp,
    clearLevelUp,
    pendingFreezeUsed,
    clearFreezeUsed,
    pendingStreakMilestone,
    clearStreakMilestone,
  } = useUser();
  // Priority order so modals never stack: a level-up is the biggest win and
  // takes precedence, then a freeze-used notice (time-sensitive transparency
  // about something that just happened), then a streak milestone celebration.
  // A freeze-used event and a streak-milestone event can't co-occur (they're
  // mutually exclusive branches of the same day-check), but level-up can
  // overlap with either.
  if (pendingLevelUp) {
    return <LevelUpModal level={pendingLevelUp.level} onClose={clearLevelUp} />;
  }
  if (pendingFreezeUsed) {
    return (
      <StreakFreezeUsedModal
        freezesRemaining={pendingFreezeUsed.freezesRemaining}
        onClose={clearFreezeUsed}
      />
    );
  }
  return <StreakMilestoneModal days={pendingStreakMilestone} onClose={clearStreakMilestone} />;
}

/** Redirects to auth screens when not signed in, and to app when signed in. */
function AuthRedirect() {
  const { isSignedIn, isLoaded } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (!isLoaded) return;

    const inAuthGroup = segments[0] === "(auth)";

    if (!isSignedIn && !inAuthGroup) {
      router.replace("/(auth)/sign-in");
    } else if (isSignedIn && inAuthGroup) {
      router.replace("/");
    }
  }, [isSignedIn, isLoaded, segments]);

  return null;
}

function RevenueCatIdentitySync() {
  const { isLoaded, isSignedIn, userId } = useAuth();

  useEffect(() => {
    if (!isLoaded) return;
    if (isSignedIn && userId) {
      logInUser(userId).catch(() => {});
    } else {
      logOutUser().catch(() => {});
    }
  }, [isLoaded, isSignedIn, userId]);

  return null;
}

function RootLayoutNav() {
  return (
    <>
      <AuthRedirect />
      <Stack screenOptions={{ headerShown: false, animation: "fade" }}>
        <Stack.Screen name="(auth)" options={{ headerShown: false, animation: "fade" }} />
        <Stack.Screen
          name="onboarding"
          options={{ headerShown: false, gestureEnabled: false, animation: "fade" }}
        />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen
          name="privacy-policy"
          options={{ headerShown: false, presentation: "card" }}
        />
      </Stack>
      <GlobalCelebrations />
    </>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (Platform.OS !== "web") {
      initializePurchases().catch(() => {});
    }
  }, []);

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <ClerkProvider
                publishableKey={publishableKey}
                tokenCache={tokenCache}
                proxyUrl={proxyUrl}
              >
                <ClerkLoaded>
                  <RevenueCatIdentitySync />
                  <UserProvider>
                    <RootLayoutNav />
                  </UserProvider>
                </ClerkLoaded>
              </ClerkProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
